// Navigazione tra le sezioni
function showSection(id) {
  document.querySelectorAll('section').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// Logica Media
function calcolaMedia() {
  const val = document.getElementById('votiInput').value;
  const voti = val.split(',').map(v => parseFloat(v.trim())).filter(v => !isNaN(v));
  const media = voti.reduce((a, b) => a + b, 0) / voti.length;
  document.getElementById('valoreMedia').innerText = voti.length ? media.toFixed(2) : "--";
}

// Logica Ripasso
function dividiRipasso() {
  const p = document.getElementById('pagine').value;
  const g = document.getElementById('giorni').value;
  if(p && g) {
    const pagAlGiorno = Math.ceil(p / g);
    document.getElementById('pianoRisultato').innerText = `Dovrai studiare circa ${pagAlGiorno} pagine al giorno.`;
  }
}

// Logica Pomodoro
let timer;
let timeLeft = 25 * 60;

function startTimer() {
  clearInterval(timer);
  timer = setInterval(() => {
    if(timeLeft <= 0) {
      clearInterval(timer);
      alert("Pausa!");
    } else {
      timeLeft--;
      updateDisplay();
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(timer);
  timeLeft = 25 * 60;
  updateDisplay();
}

function updateDisplay() {
  const min = Math.floor(timeLeft / 60);
  const sec = timeLeft % 60;
  document.getElementById('timer').innerText = `${min}:${sec < 10 ? '0'+sec : sec}`;
}
// Carica i riassunti già salvati all'avvio
document.addEventListener('DOMContentLoaded', mostraRiassunti);

function caricaRiassunto() {
  const titolo = document.getElementById('titoloRiassunto').value;
  const link = document.getElementById('linkRiassunto').value;

  if (titolo === '' || link === '') {
    alert("Inserisci sia il titolo che il link!");
    return;
  }

  const nuovoRiassunto = { titolo, link };

  // Salvataggio in LocalStorage (Memoria del browser)
  let riassunti = JSON.parse(localStorage.getItem('riassunti')) || [];
  riassunti.push(nuovoRiassunto);
  localStorage.setItem('riassunti', JSON.stringify(riassunti));

  // Pulisci input e aggiorna lista
  document.getElementById('titoloRiassunto').value = '';
  document.getElementById('linkRiassunto').value = '';
  mostraRiassunti();
}

function mostraRiassunti() {
  const lista = document.getElementById('listaRiassunti');
  const riassunti = JSON.parse(localStorage.getItem('riassunti')) || [];
  
  lista.innerHTML = riassunti.map(r => `
    <div class="card-riassunto">
      <span>${r.titolo}</span>
      <a href="${r.link}" target="_blank">Apri ↗</a>
    </div>
  `).join('');
}